import express from 'express';
import OpenAI from 'openai';
import dotenv from 'dotenv';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

dotenv.config();
const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(express.json({ limit: '12mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
app.post('/api/ask', async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: 'مفتاح الخدمة غير مضبوط على الخادم.' });
    const content = Array.isArray(req.body?.content) ? req.body.content : null;
    if (!content || !content.length) return res.status(400).json({ error: 'لم يصل نص السؤال.' });
    const result = await client.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [{ role: 'user', content }],
      max_tokens: 1200
    });
    res.json({ answer: result.choices?.[0]?.message?.content || 'لم يصل رد من الأستاذ الذكي.' });
  } catch (err) {
    console.error('AI request failed:', err?.message || err);
    res.status(500).json({ error: 'صار خطأ أثناء طلب إجابة الذكاء الاصطناعي. تحقق من إعداد الخادم.' });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`StudyHub server listening on ${port}`));
